<?php
use Medoo\Medoo;

return new Medoo([
    'type' => 'mysql',
    'host' => 'localhost',
    'database' => 'knowledge_system',
    'username' => 'root',
    'password' => ''
]);
