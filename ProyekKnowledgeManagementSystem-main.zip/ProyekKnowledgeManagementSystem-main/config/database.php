<?php
use Medoo\Medoo;

return new Medoo([
    'type' => 'mysql',
    'host' => 'localhost',
    'database' => 'nama_database_kamu',
    'username' => 'root',
    'password' => ''
]);
